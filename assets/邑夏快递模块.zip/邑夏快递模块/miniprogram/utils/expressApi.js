/**
 * 邑夏小程序 · 快递API封装
 * 对接后端 /api/express 接口
 */

const BASE_URL = 'https://你的后端地址';  // 替换为实际后端地址

const request = (url, method = 'GET', data = {}) => {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${BASE_URL}${url}`,
      method,
      data,
      header: { 'content-type': 'application/json' },
      success: (res) => {
        if (res.data.success) {
          resolve(res.data.data);
        } else {
          reject(new Error(res.data.message || '请求失败'));
        }
      },
      fail: (err) => reject(err),
    });
  });
};

module.exports = {
  /**
   * 获取支持的快递公司列表
   */
  getCompanies() {
    return request('/api/express/companies');
  },

  /**
   * 获取已绑定的快递账号
   */
  getAccounts() {
    return request('/api/express/accounts');
  },

  /**
   * 创建快递订单（获取电子面单）
   * @param {Object} params
   * @param {string} params.orderId - 商户订单号
   * @param {string} params.expressCompany - 快递公司ID（默认JDL）
   * @param {Object} params.receiver - 收件人信息
   * @param {Object} params.cargo - 货物信息
   * @param {string} params.remark - 备注
   */
  createOrder(params) {
    return request('/api/express/order', 'POST', {
      orderId: params.orderId,
      expressCompany: params.expressCompany || 'JDL',
      receiver: params.receiver,
      sender: params.sender,
      cargo: params.cargo,
      remark: params.remark || '',
      getPrintData: true,
    });
  },

  /**
   * 查询订单/面单信息
   */
  getOrder(orderId, waybillId) {
    return request(`/api/express/order/${orderId}?waybillId=${waybillId || ''}&getPrintData=true`);
  },

  /**
   * 取消快递订单
   */
  cancelOrder(orderId, waybillId) {
    return request(`/api/express/order/${orderId}?waybillId=${waybillId || ''}`, 'DELETE');
  },

  /**
   * 获取面单打印数据
   */
  getPrintData(orderId, waybillId) {
    return request(`/api/express/print/${orderId}`, 'POST', { waybillId });
  },

  /**
   * 批量创建快递订单
   */
  batchCreateOrders(orders) {
    return request('/api/express/batch', 'POST', { orders });
  },

  /**
   * 格式化收件人地址
   */
  formatAddress(province, city, area, address) {
    return `${province}${city}${area}${address}`;
  },
};

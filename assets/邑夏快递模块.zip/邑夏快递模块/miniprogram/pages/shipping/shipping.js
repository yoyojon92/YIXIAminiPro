// pages/shipping/shipping.js
const expressApi = require('../../utils/expressApi');

Page({
  data: {
    // 订单信息
    orderId: '',
    expressCompany: 'JDL',
    expressCompanyName: '京东快递',
    
    // 快递公司选择
    companies: [],
    showCompanyPicker: false,
    
    // 收件人
    receiver: {
      name: '',
      mobile: '',
      province: '',
      city: '',
      area: '',
      address: '',
    },
    
    // 货物
    cargo: {
      name: '果酒',
      count: 1,
      weight: 1.0,
    },
    
    remark: '',
    
    // 面单数据
    waybillId: '',
    waybillHtml: '',
    waybillImageUrl: '',
    
    // 状态
    loading: false,
    orderCreated: false,
    printing: false,
  },

  onLoad(options) {
    // 从上一页传入的订单信息
    if (options.orderId) {
      this.setData({ orderId: options.orderId });
    }
    if (options.receiver) {
      try {
        const receiver = JSON.parse(decodeURIComponent(options.receiver));
        this.setData({ receiver });
      } catch (e) {}
    }
    this.loadCompanies();
  },

  // 加载快递公司列表
  async loadCompanies() {
    try {
      const companies = await expressApi.getCompanies();
      this.setData({ companies });
    } catch (err) {
      console.error('加载快递公司失败:', err);
    }
  },

  // 选择快递公司
  onCompanyTap() {
    this.setData({ showCompanyPicker: true });
  },

  onCompanySelect(e) {
    const { id, name } = e.currentTarget.dataset;
    this.setData({
      expressCompany: id,
      expressCompanyName: name,
      showCompanyPicker: false,
    });
  },

  onCompanyPickerClose() {
    this.setData({ showCompanyPicker: false });
  },

  // 收件人信息输入
  onReceiverInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`receiver.${field}`]: e.detail.value });
  },

  // 选择收件地址（微信地址选择）
  onChooseAddress() {
    wx.chooseAddress({
      success: (res) => {
        this.setData({
          'receiver.name': res.userName,
          'receiver.mobile': res.telNumber,
          'receiver.province': res.provinceName,
          'receiver.city': res.cityName,
          'receiver.area': res.countyName,
          'receiver.address': res.detailInfo,
        });
      },
      fail: (err) => {
        console.log('用户取消选择地址');
      },
    });
  },

  // 货物信息输入
  onCargoInput(e) {
    const field = e.currentTarget.dataset.field;
    const value = field === 'count' || field === 'weight' ? Number(e.detail.value) : e.detail.value;
    this.setData({ [`cargo.${field}`]: value });
  },

  onRemarkInput(e) {
    this.setData({ remark: e.detail.value });
  },

  // 创建快递订单
  async onCreateOrder() {
    const { orderId, expressCompany, receiver, cargo, remark } = this.data;

    // 校验
    if (!receiver.name || !receiver.mobile || !receiver.province || !receiver.city || !receiver.area || !receiver.address) {
      wx.showToast({ title: '请完善收件人信息', icon: 'none' });
      return;
    }

    this.setData({ loading: true });

    try {
      const result = await expressApi.createOrder({
        orderId,
        expressCompany,
        receiver,
        cargo,
        remark,
      });

      this.setData({
        waybillId: result.waybillId,
        waybillHtml: expressApi.extractHtml ? '' : '',  // 后端已处理
        orderCreated: true,
        loading: false,
      });

      wx.showToast({ title: '下单成功！运单号: ' + result.waybillId, icon: 'none', duration: 3000 });
    } catch (err) {
      this.setData({ loading: false });
      wx.showModal({
        title: '下单失败',
        content: err.message,
        showCancel: false,
      });
    }
  },

  // 打印面单
  async onPrintWaybill() {
    const { orderId, waybillId } = this.data;
    if (!orderId || !waybillId) return;

    this.setData({ printing: true });

    try {
      const printData = await expressApi.getPrintData(orderId, waybillId);

      if (printData.html) {
        // 方式1：通过微信打单PC软件打印
        // 需要在PC端运行微信打单软件
        wx.showToast({ title: '面单已发送到打印服务', icon: 'success' });
      } else if (printData.imageUrl) {
        // 方式2：预览面单图片
        wx.previewImage({
          urls: [printData.imageUrl],
          current: printData.imageUrl,
        });
      } else {
        wx.showToast({ title: '暂无面单数据', icon: 'none' });
      }
    } catch (err) {
      wx.showModal({
        title: '获取面单失败',
        content: err.message,
        showCancel: false,
      });
    } finally {
      this.setData({ printing: false });
    }
  },

  // 取消订单
  onCancelOrder() {
    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个快递订单吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            await expressApi.cancelOrder(this.data.orderId, this.data.waybillId);
            this.setData({ orderCreated: false, waybillId: '' });
            wx.showToast({ title: '已取消', icon: 'success' });
          } catch (err) {
            wx.showToast({ title: err.message, icon: 'none' });
          }
        }
      },
    });
  },

  // 确认发货（更新订单状态）
  onConfirmShipped() {
    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2];
    if (prevPage) {
      prevPage.setData({
        [`order.shipped`]: true,
        [`order.waybillId`]: this.data.waybillId,
        [`order.expressCompany`]: this.data.expressCompanyName,
      });
    }
    wx.showToast({ title: '已确认发货', icon: 'success' });
    setTimeout(() => wx.navigateBack(), 1500);
  },
});

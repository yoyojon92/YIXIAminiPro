# 邑夏小程序 · 微信物流助手快递模块

> 基于微信小程序物流助手API，对接京东快递（支持一键切换60+快递公司）
> 电子面单下单 → 面单获取 → 热敏打印 → 发货回传

## 项目结构

```
├── server/                  # 后端服务（Node.js）
│   ├── config/
│   │   └── index.js         # 配置文件（AppID/Secret/快递公司等）
│   ├── utils/
│   │   └── wxToken.js       # 微信AccessToken管理
│   ├── services/
│   │   └── expressService.js # 快递核心业务逻辑
│   ├── routes/
│   │   └── express.js       # API路由
│   ├── app.js               # Express入口
│   └── package.json
├── miniprogram/             # 小程序前端
│   ├── utils/
│   │   └── expressApi.js    # 快递API封装
│   ├── pages/shipping/
│   │   ├── shipping.js      # 发货页面
│   │   ├── shipping.wxml
│   │   ├── shipping.wxss
│   │   └── shipping.json
│   └── components/
│       └── express-picker/  # 快递公司选择器
├── docs/
│   └── 接入指南.md
└── README.md
```

## 快速开始

### 1. 后端部署

```bash
cd server
npm install
# 修改 config/index.js 中的配置
cp .env.example .env
npm start
```

### 2. 小程序配置

在小程序后台 → 物流助手 → 绑定京东快递网点账号

### 3. 前置条件

- 微信小程序已开通物流助手权限
- 已与京东快递网点签约（获取账号密码）
- 热敏打印机（100×150mm 或 76×105mm 面单纸）

## 支持的快递公司

| 快递公司 | ID | 需签约 |
|---------|-----|-------|
| 京东快递 | JDL | 是 |
| 顺丰速运 | SF | 是/散单 |
| 中通快递 | ZTO | 是 |
| 圆通速递 | YTO | 是 |
| 韵达快递 | YUNDA | 是 |
| 申通快递 | STO | 是 |
| 极兔快递 | JTSD | 是 |
| 德邦快递 | DB | 是/散单 |

切换快递公司：修改 config 中的 `defaultExpress` 即可。

## API接口

| 接口 | 方法 | 说明 |
|------|------|------|
| /api/express/accounts | GET | 获取已绑定的快递账号 |
| /api/express/order | POST | 创建快递订单（获取面单） |
| /api/express/order/:id | GET | 查询订单/面单信息 |
| /api/express/order/:id | DELETE | 取消订单 |
| /api/express/print/:id | POST | 获取面单打印数据 |
| /api/express/callback | POST | 微信物流回调 |

## 打印方案

1. **微信打单PC软件**（推荐）：下载微信官方打单软件，连接热敏打印机
2. **自建打印服务**：获取面单HTML/图片数据，通过本地打印服务发送到打印机
3. **快递管家**：第三方打单软件，已对接微信物流助手

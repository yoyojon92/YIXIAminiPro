const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const config = require('./config');
const expressRouter = require('./routes/express');

const app = express();

// 中间件
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// 路由
app.use('/api/express', expressRouter);

// 健康检查
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'yixia-express', version: '1.0.0' });
});

// 错误处理
app.use((err, req, res, next) => {
  console.error('[Server] 未捕获异常:', err);
  res.status(500).json({ success: false, message: '服务器内部错误' });
});

// 启动
const PORT = config.server.port;
app.listen(PORT, config.server.host, () => {
  console.log(`[邑夏快递模块] 服务启动: http://${config.server.host}:${PORT}`);
  console.log(`[邑夏快递模块] 默认快递: ${config.express.companies[config.express.defaultExpress]?.name || config.express.defaultExpress}`);
  console.log(`[邑夏快递模块] API文档: http://${config.server.host}:${PORT}/api/express/companies`);
});

module.exports = app;

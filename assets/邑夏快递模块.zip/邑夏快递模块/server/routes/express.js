const express = require('express');
const router = express.Router();
const expressService = require('../services/expressService');
const config = require('../config');

/**
 * GET /api/express/companies
 * 获取支持的快递公司列表
 */
router.get('/companies', (req, res) => {
  const companies = Object.entries(config.express.companies).map(([id, info]) => ({
    id,
    name: info.name,
    serviceType: info.serviceType,
    serviceName: info.serviceName,
    mode: info.mode,
    bound: !!config.express.bizIds[id],
  }));
  res.json({ success: true, data: companies });
});

/**
 * GET /api/express/accounts
 * 获取已绑定的快递账号
 */
router.get('/accounts', async (req, res) => {
  try {
    const accounts = await expressService.getAccounts();
    res.json({ success: true, data: accounts });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/express/accounts/bind
 * 绑定快递公司账号
 */
router.post('/accounts/bind', async (req, res) => {
  try {
    const { type, bizId, password } = req.body;
    if (!type || !bizId || !password) {
      return res.status(400).json({ success: false, message: '缺少参数: type, bizId, password' });
    }
    const result = await expressService.bindAccount(type, bizId, password);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/express/order
 * 创建快递订单（获取电子面单）
 * 
 * Body:
 * {
 *   "orderId": "YX20260520001",
 *   "expressCompany": "JDL",       // 可选，默认JDL
 *   "receiver": {
 *     "name": "张三",
 *     "mobile": "13800138000",
 *     "province": "广东省",
 *     "city": "深圳市",
 *     "area": "南山区",
 *     "address": "科技园路1号"
 *   },
 *   "cargo": {
 *     "name": "楂香四溢果酒",
 *     "count": 2,
 *     "weight": 1.5
 *   },
 *   "remark": "易碎品，轻拿轻放",
 *   "getPrintData": true
 * }
 */
router.post('/order', async (req, res) => {
  try {
    const { orderId, expressCompany, receiver, sender, cargo, remark, getPrintData, openid, bizId } = req.body;

    if (!orderId) {
      return res.status(400).json({ success: false, message: '缺少订单号: orderId' });
    }
    if (!receiver || !receiver.name || !receiver.mobile || !receiver.province || !receiver.city || !receiver.area || !receiver.address) {
      return res.status(400).json({ success: false, message: '收件人信息不完整，需要: name, mobile, province, city, area, address' });
    }

    const result = await expressService.createOrder({
      orderId,
      expressCompany: expressCompany || config.express.defaultExpress,
      bizId,
      sender,
      receiver,
      cargo,
      remark,
      openid,
      orderFlag: getPrintData ? 1 : 0,
    });

    res.json({ success: true, data: result });
  } catch (err) {
    console.error('[Route] 创建快递订单失败:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/express/order/:orderId
 * 查询订单/面单信息
 * Query: waybillId, getPrintData
 */
router.get('/order/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const { waybillId, getPrintData } = req.query;
    const result = await expressService.getOrder(orderId, waybillId, getPrintData === 'true');
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * DELETE /api/express/order/:orderId
 * 取消快递订单
 */
router.delete('/order/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const { waybillId, openid } = req.query;
    const result = await expressService.cancelOrder(orderId, waybillId, openid);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/express/print/:orderId
 * 获取面单打印数据
 */
router.post('/print/:orderId', async (req, res) => {
  try {
    const { orderId } = req.params;
    const { waybillId } = req.body;
    const result = await expressService.getOrder(orderId, waybillId, true);

    // 提取不同格式的面单数据
    const htmlContent = expressService.extractWaybillHtml(result.waybillData);
    const imageUrl = expressService.extractWaybillImage(result.waybillData);
    const rawData = expressService.extractWaybillRaw(result.waybillData);

    res.json({
      success: true,
      data: {
        orderId: result.orderId,
        waybillId: result.waybillId,
        html: htmlContent,
        imageUrl,
        raw: rawData,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/express/batch
 * 批量创建快递订单
 */
router.post('/batch', async (req, res) => {
  try {
    const { orders } = req.body;
    if (!Array.isArray(orders) || orders.length === 0) {
      return res.status(400).json({ success: false, message: 'orders必须是非空数组' });
    }
    if (orders.length > 50) {
      return res.status(400).json({ success: false, message: '单次批量最多50单' });
    }
    const result = await expressService.batchCreateOrders(orders);
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/express/callback
 * 微信物流回调（快递状态变更通知）
 * 需在小程序后台配置回调URL
 */
router.post('/callback', (req, res) => {
  console.log('[Callback] 收到物流回调:', JSON.stringify(req.body));

  // 微信物流回调数据结构
  // {
  //   "ToUserName": "gh_xxx",
  //   "FromUserName": "oxxx",
  //   "CreateTime": 1234567890,
  //   "MsgType": "event",
  //   "Event": "express_status_notify",
  //   "DeliveryStatus": { ... }
  // }

  // TODO: 根据回调数据更新订单物流状态
  // 1. 解析运单号和状态
  // 2. 更新数据库中的订单物流状态
  // 3. 推送通知给用户

  res.json({ errcode: 0, errmsg: 'success' });
});

module.exports = router;

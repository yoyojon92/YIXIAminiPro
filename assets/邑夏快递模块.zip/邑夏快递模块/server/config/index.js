require('dotenv').config();

module.exports = {
  // 微信小程序
  wx: {
    appId: process.env.WX_APPID,
    appSecret: process.env.WX_SECRET,
  },

  // 服务器
  server: {
    port: process.env.PORT || 3000,
    host: process.env.HOST || '0.0.0.0',
  },

  // 快递公司配置 —— 切换快递只改这里
  express: {
    // 默认快递公司ID
    defaultExpress: process.env.DEFAULT_EXPRESS || 'JDL',

    // 快递公司映射表
    companies: {
      JDL:   { name: '京东快递',   id: 'JDL',   serviceType: 0, serviceName: '特惠送',   mode: '直营' },
      SF:    { name: '顺丰速运',   id: 'SF',    serviceType: 0, serviceName: '标准快递',  mode: '直营' },
      ZTO:   { name: '中通快递',   id: 'ZTO',   serviceType: 0, serviceName: '标准快件',  mode: '加盟' },
      YTO:   { name: '圆通速递',   id: 'YTO',   serviceType: 0, serviceName: '普通快递',  mode: '加盟' },
      YUNDA: { name: '韵达快递',   id: 'YUNDA', serviceType: 0, serviceName: '标准快件',  mode: '加盟' },
      STO:   { name: '申通快递',   id: 'STO',   serviceType: 1, serviceName: '标准快递',  mode: '加盟' },
      JTSD:  { name: '极兔快递',   id: 'JTSD',  serviceType: 0, serviceName: '标准快递',  mode: '加盟' },
      DB:    { name: '德邦快递',   id: 'DB',    serviceType: 1, serviceName: '大件快递3.60', mode: '直营' },
      EMS:   { name: '邮政EMS',    id: 'EMS',   serviceType: 6, serviceName: '标准快递',  mode: '直营' },
      BEST:  { name: '百世快递',   id: 'BEST',  serviceType: 1, serviceName: '普通快递',  mode: '加盟' },
    },

    // 各快递公司签约账号（biz_id）—— 签约后填入
    bizIds: {
      JDL: process.env.JD_BIZ_ID || '',
      // SF: '你的顺丰网点账号',
      // ZTO: '你的中通网点账号',
    },
  },

  // 发件人默认信息（邑夏酒馆）
  sender: {
    name: '邑夏酒馆',
    mobile: '',       // 填入发货手机号
    province: '',     // 填入省份
    city: '',         // 填入城市
    area: '',         // 填入区县
    address: '',      // 填入详细地址
  },

  // 打印服务
  printer: {
    name: process.env.PRINTER_NAME || '',
    printServerPort: process.env.PRINT_SERVER_PORT || 3001,
  },
};

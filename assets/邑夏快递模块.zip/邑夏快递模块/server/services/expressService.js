const axios = require('axios');
const wxToken = require('../utils/wxToken');
const config = require('../config');

const BASE_URL = 'https://api.weixin.qq.com';

class ExpressService {
  /**
   * 获取所有已绑定的快递账号
   * GET /cgi-bin/express/business/account/getall
   */
  async getAccounts() {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/account/getall?access_token=${token}`;
    const res = await axios.post(url, {});
    if (res.data.errcode !== 0) {
      throw new Error(`获取快递账号失败: ${res.data.errmsg}`);
    }
    return res.data.account_list || [];
  }

  /**
   * 绑定快递公司账号
   * POST /cgi-bin/express/business/account/bind
   */
  async bindAccount(type, bizId, password) {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/account/bind?access_token=${token}`;
    const res = await axios.post(url, { type, biz_id: bizId, password });
    if (res.data.errcode !== 0) {
      throw new Error(`绑定快递账号失败: ${res.data.errmsg}`);
    }
    return res.data;
  }

  /**
   * 解绑快递公司账号
   */
  async unbindAccount(type, bizId) {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/account/bind?access_token=${token}`;
    const res = await axios.post(url, { type, biz_id: bizId, unbind: true });
    if (res.data.errcode !== 0) {
      throw new Error(`解绑快递账号失败: ${res.data.errmsg}`);
    }
    return res.data;
  }

  /**
   * 创建快递订单（核心接口）
   * POST /cgi-bin/express/business/order/add
   * 
   * @param {Object} params
   * @param {string} params.orderId - 商户订单号（唯一）
   * @param {string} params.expressCompany - 快递公司ID，如 JDL
   * @param {string} params.bizId - 签约网点账号
   * @param {Object} params.sender - 发件人信息
   * @param {Object} params.receiver - 收件人信息
   * @param {Object} params.cargo - 货物信息
   * @param {number} params.serviceType - 服务类型ID
   * @returns {Object} { waybill_id, order_id, waybill_data, ... }
   */
  async createOrder(params) {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/order/add?access_token=${token}`;

    // 快递公司信息
    const companyConfig = config.express.companies[params.expressCompany || config.express.defaultExpress];
    if (!companyConfig) {
      throw new Error(`不支持的快递公司: ${params.expressCompany}`);
    }

    // bizId：优先用传入的，否则从配置取
    const bizId = params.bizId || config.express.bizIds[companyConfig.id];
    if (!bizId) {
      throw new Error(`快递公司 ${companyConfig.name} 尚未签约，请先绑定网点账号`);
    }

    // 构建请求体
    const body = {
      order_id: params.orderId,
      openid: params.openid || '',          // 用户openid（可选，用于推送物流通知）
      delivery_id: companyConfig.id,        // 快递公司ID
      biz_id: bizId,                        // 网点账号
      service_type: params.serviceType ?? companyConfig.serviceType,

      // 发件人
      sender: {
        name: params.sender?.name || config.sender.name,
        mobile: params.sender?.mobile || config.sender.mobile,
        province: params.sender?.province || config.sender.province,
        city: params.sender?.city || config.sender.city,
        area: params.sender?.area || config.sender.area,
        address: params.sender?.address || config.sender.address,
      },

      // 收件人
      receiver: {
        name: params.receiver.name,
        mobile: params.receiver.mobile,
        province: params.receiver.province,
        city: params.receiver.city,
        area: params.receiver.area,
        address: params.receiver.address,
      },

      // 货物信息
      cargo: {
        count: params.cargo?.count || 1,
        weight: params.cargo?.weight || 1.0,       // kg
        detail_list: params.cargo?.detailList || [
          { name: params.cargo?.name || '果酒', count: params.cargo?.count || 1 }
        ],
      },

      // 备注
      remark: params.remark || '',

      // 是否获取面单打印数据
      order_flag: params.orderFlag || 0,    // 0=不获取, 1=获取面单数据
    };

    console.log(`[Express] 创建快递订单: ${params.orderId}, 快递: ${companyConfig.name}`);

    const res = await axios.post(url, body);
    if (res.data.errcode !== 0) {
      console.error(`[Express] 创建订单失败:`, res.data);
      throw new Error(`创建快递订单失败: ${res.data.errmsg}`);
    }

    const result = {
      orderId: params.orderId,
      waybillId: res.data.waybill_id,
      waybillData: res.data.waybill_data || [],
      expressCompany: companyConfig.id,
      expressCompanyName: companyConfig.name,
    };

    console.log(`[Express] 订单创建成功: 运单号=${result.waybillId}`);
    return result;
  }

  /**
   * 获取电子面单数据（用于打印）
   * POST /cgi-bin/express/business/order/get
   * 
   * @param {string} orderId - 商户订单号
   * @param {string} waybillId - 运单号
   * @param {boolean} getPrintData - 是否获取面单打印数据
   */
  async getOrder(orderId, waybillId, getPrintData = true) {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/order/get?access_token=${token}`;

    const body = {
      order_id: orderId,
      waybill_id: waybillId || '',
      order_flag: getPrintData ? 1 : 0,   // 1=获取面单打印数据
    };

    const res = await axios.post(url, body);
    if (res.data.errcode !== 0) {
      throw new Error(`获取面单失败: ${res.data.errmsg}`);
    }

    return {
      orderId: res.data.order_id,
      waybillId: res.data.waybill_id,
      waybillData: res.data.waybill_data || [],
      printData: res.data.print_data || null,
    };
  }

  /**
   * 取消快递订单
   * POST /cgi-bin/express/business/order/cancel
   */
  async cancelOrder(orderId, waybillId, openid = '') {
    const token = await wxToken.getAccessToken();
    const url = `${BASE_URL}/cgi-bin/express/business/order/cancel?access_token=${token}`;

    const body = {
      order_id: orderId,
      waybill_id: waybillId || '',
      openid,
    };

    const res = await axios.post(url, body);
    if (res.data.errcode !== 0) {
      throw new Error(`取消订单失败: ${res.data.errmsg}`);
    }

    console.log(`[Express] 订单已取消: ${orderId}`);
    return res.data;
  }

  /**
   * 获取面单HTML打印数据
   * 从 waybill_data 中提取HTML格式面单
   */
  extractWaybillHtml(waybillData) {
    if (!waybillData || !Array.isArray(waybillData)) return null;

    for (const item of waybillData) {
      if (item.type === 'html' || item.type === 'HTML') {
        return item.content;
      }
    }
    return null;
  }

  /**
   * 获取面单图片URL
   */
  extractWaybillImage(waybillData) {
    if (!waybillData || !Array.isArray(waybillData)) return null;

    for (const item of waybillData) {
      if (item.type === 'image' || item.type === 'IMAGE') {
        return item.content;  // 图片URL
      }
    }
    return null;
  }

  /**
   * 获取面单原始数据（自定义排版用）
   */
  extractWaybillRaw(waybillData) {
    if (!waybillData || !Array.isArray(waybillData)) return null;

    const result = {};
    for (const item of waybillData) {
      if (item.type === 'raw' || item.type === 'RAW') {
        // raw数据通常包含收件人/发件人/条码等键值对
        Object.assign(result, item.content || {});
      }
    }
    return Object.keys(result).length > 0 ? result : null;
  }

  /**
   * 批量创建快递订单
   * @param {Array} orders - 订单数组
   */
  async batchCreateOrders(orders) {
    const results = [];
    const errors = [];

    for (const order of orders) {
      try {
        const result = await this.createOrder(order);
        results.push(result);
      } catch (err) {
        errors.push({ orderId: order.orderId, error: err.message });
      }
    }

    return { results, errors, total: orders.length, success: results.length, failed: errors.length };
  }
}

module.exports = new ExpressService();

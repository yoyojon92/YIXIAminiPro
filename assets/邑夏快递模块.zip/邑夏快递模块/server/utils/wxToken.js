const axios = require('axios');
const config = require('../config');

class WxTokenManager {
  constructor() {
    this.accessToken = null;
    this.expiresAt = 0;
  }

  /**
   * 获取有效的AccessToken，自动刷新
   */
  async getAccessToken() {
    // 提前5分钟刷新，避免边界问题
    if (this.accessToken && Date.now() < this.expiresAt - 300000) {
      return this.accessToken;
    }

    const url = 'https://api.weixin.qq.com/cgi-bin/token';
    const params = {
      grant_type: 'client_credential',
      appid: config.wx.appId,
      secret: config.wx.appSecret,
    };

    try {
      const res = await axios.get(url, { params });
      if (res.data.access_token) {
        this.accessToken = res.data.access_token;
        this.expiresAt = Date.now() + (res.data.expires_in || 7200) * 1000;
        console.log('[Token] AccessToken刷新成功，有效期至:', new Date(this.expiresAt).toLocaleString());
        return this.accessToken;
      }
      throw new Error(`获取AccessToken失败: ${JSON.stringify(res.data)}`);
    } catch (err) {
      console.error('[Token] 获取AccessToken异常:', err.message);
      throw err;
    }
  }

  /**
   * 强制刷新Token
   */
  async forceRefresh() {
    this.accessToken = null;
    this.expiresAt = 0;
    return this.getAccessToken();
  }
}

// 单例
module.exports = new WxTokenManager();
